package com.heima.item.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.heima.item.pojo.ItemStock;

public interface ItemStockMapper extends BaseMapper<ItemStock> {
}
