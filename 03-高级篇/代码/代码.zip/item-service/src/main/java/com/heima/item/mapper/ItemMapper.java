package com.heima.item.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.heima.item.pojo.Item;

public interface ItemMapper extends BaseMapper<Item> {
}
