-- echo command line arguments

for i=0,table.getn(arg) do
 print(i,arg[i])
end
